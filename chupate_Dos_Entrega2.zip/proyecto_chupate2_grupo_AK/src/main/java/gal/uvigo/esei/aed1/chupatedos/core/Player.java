package gal.uvigo.esei.aed1.chupatedos.core;

import java.util.ArrayList;
import java.util.List;

public class Player {

    private final String name;
    private final List<Card> hand;
    // Lista de cartas (mano/hand)

    // Método constructor
    public Player(String name) {
        this.name = name;
        this.hand = new ArrayList<>();
    }

    // Getter para obtener el nombre del jugador al mostrar el estado de la mesa
    public String getName() {
        return name;
    }

    // Método para añadir carta a la mano del jugador
    public void addCard(Card card) {
        hand.add(card);
    }
    
    public void removeCard(Card card)
    {
        hand.remove(card);
    }
    
    public List<Card> playableCards(Card cardOnTable) {
    List<Card> playable = new ArrayList<>();
    for (Card c : hand) {
        if (c.getNumber() == cardOnTable.getNumber() || c.getSuit() == cardOnTable.getSuit()) {
            playable.add(c); // NO la quitamos aún
        }
    }
    return playable;
}

    public List<Card> getHand() {
        return hand;
    }
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Jugador: ").append(name);
        sb.append("\nMano: ").append(hand);
        sb.append('}');
        return sb.toString();
    }

    

}
