package gal.uvigo.esei.aed1.chupatedos.core;

import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class DeckOfCards {

    private final Stack<Card> deck;

    // Método constructor creamos deck y añadimos las 40 cartas de la baraja española.
    public DeckOfCards() {
        deck = new Stack<>();
        for (Card card : Card.values()) {
            deck.push(card);
        }
    }

    // Método para barajar 
    public void shuffle() {
        Collections.shuffle(deck);
    }

    // Coger la siguiente carta (top) de la baraja usando pop. Elimina la carta de la baraja al repartir.
    public Card deal() {
        return deck.pop();
    }

    // Método para saber la cantidad de cartas que quedan en la baraja
    public int getRemainingCards() {
        return deck.size();
    }
    
    public boolean isEmpty(){
        return deck.size()==0;
    }
    
    public void recycleFromTable(List<Card> cards)
    {
        this.deck.addAll(cards);
    }
   
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(deck);
        return sb.toString();
    }

    
}
