package gal.uvigo.esei.aed1.chupatedos.core;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Stack;


public class Table {

    // Stack para cartas boca arriba
    private final Stack<Card> faceupCards;
    
    // Constructor del stack de cartas vacío;
    public Table(){
        faceupCards = new Stack<>();    
    }

    // Colocar una carta en la pila (método push)
    public void placeCard(Card card){
        faceupCards.push(card);
    }
    
    // Hace visible la carta que está en la cima de la pila (método peek)
    public Card getTopCard() throws EmptyStackException{   
        return faceupCards.peek();
    }
    
    // Número de cartas que hay boca arriba
    public int getFaceupCounter(){
        return faceupCards.size(); 
    }
    
    //Limpia toda la mesa y deja la última carta encima
    public List<Card> clearTable() {
    List<Card> returned = new ArrayList<>();
    for (int i = 0; i < faceupCards.size() - 1; i++) {
        returned.add(faceupCards.get(i));
    }
    Card last = faceupCards.get(faceupCards.size() - 1);
    faceupCards.clear();
    faceupCards.add(last);
    return returned;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Table{");
        sb.append("faceupCards=").append(faceupCards);
        sb.append('}');
        return sb.toString();
    }
    
    
    
   
    

    

    
}
