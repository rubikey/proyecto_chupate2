package gal.uvigo.esei.aed1.chupatedos.core;

import gal.uvigo.esei.aed1.chupatedos.iu.IU;
import java.util.ArrayList;
import java.util.List;

public class Game {

    // Atributos de la clase Game
    private final IU iu; // Referencia a la interfaz de usuario
    private final DeckOfCards deck;
    private final Table table;
    private final List<Player> players;
    // Lista de jugadores

    // Constructor para inicializar los atributos
    public Game(IU iu) {
        this.iu = iu; // Se asigna la interfaz de usuario pasada como parámetro
        this.deck = new DeckOfCards(); // Se crea una nueva baraja
        this.table = new Table(); // Se crea una nueva mesa
        this.players = new ArrayList<>(); // Se inicializa la lista de jugadores

    }

    /**
     * Método para iniciar el juego. Solicita el número de jugadores, crea los
     * jugadores, inicializa la baraja y reparte las cartas.
     */
    public void start() {

        Player w = null;
        boolean winner = false;
        // Creamos los jugadores y los agregamos a la lista
        int numOfPlayers = iu.getNumOfPlayers();
        for (int i = 1; i <= numOfPlayers; i++) {
            // Añadimos el jugador a la lista de jugadores
            players.add(new Player(iu.readPlayerName()));
        }

        // Mezclamos la baraja
        deck.shuffle();

        // Repartimos 7 cartas a cada jugador
        for (int i = 0; i < 7; i++) {
            for (Player p : players) {
                // Recorremos la lista de jugadores para darles una carta a cada uno
                p.addCard(deck.deal());
                
            }

        }

        // Se coloca una carta en la mesa
        table.placeCard(deck.deal());

        int i = 0;

        //Recorre los jugadores mientras no haya un ganador
        while (!winner) {
            Player player = players.get(i);
            //Imprime el nombre del jugador 
            iu.displayMessage("\nTurno de: " + player.getName());

            //Imprime la carta de la mesa
            iu.displayMessage("Carta en la mesa: " + table.getTopCard());

            //Imprime la mano del jugador
            iu.displayMessage("Tu mano: " + player.getHand());

            //Sobre la mano del jugador se crea un arraylist que contiene las cartas jugables
            List<Card> jugables = player.playableCards(table.getTopCard());

            if (!jugables.isEmpty()) {
                //Se imprimen las cartas jugables
                iu.displayCards(jugables);
                int seleccion = iu.readNumber("Elige una carta por índice: ");
                while (seleccion < 0 || seleccion >= jugables.size()) {
                    seleccion = iu.readNumber("Índice inválido. Intenta de nuevo: ");
                }

                Card cartaJugada = jugables.get(seleccion);
                player.removeCard(cartaJugada);
                table.placeCard(cartaJugada);
                iu.displayMessage("Has jugado: " + cartaJugada);
            } else {
                //Comprueba previamente el mazo
                if(deck.isEmpty())
                {
                   iu.displayMessage("La baraja está vacía. Se reinicia.");
                    deck.recycleFromTable(table.clearTable());
                    deck.shuffle();     
                }
                    Card robada = deck.deal();
                    iu.displayMessage("Robas una carta: " + robada);
                    if(robada.canBePlayedOver(table.getTopCard()))
                    {
                        table.placeCard(robada);
                        iu.displayMessage("La carta es jugable. Se pone en la mesa. ");
                    }
                    else{
                        player.addCard(robada);
                        iu.displayMessage("Pierdes turno");
                    }
                
                
            }

            if (player.getHand().isEmpty()) {
                w = player;
                winner = true;

            }
            i = (i+1) % players.size();
        }

        
        iu.displayMessage("\nEl juego ha acabado y el ganador es: " + w.getName());
        

    }

}
