package gal.uvigo.esei.aed1.chupatedos.core;

/**
 * palos de la baraja española
 */
public enum Suit {
    OROS, COPAS, ESPADAS, BASTOS;
}
